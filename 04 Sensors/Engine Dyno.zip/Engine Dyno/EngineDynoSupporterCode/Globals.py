import serial

engineDynoSerialBool = False

engineDyno = serial.Serial()
